clear all;
if ~exist("conAssign")
    run C:\tomlab\startup.m
else
    disp("TomLab Initiated");
end
addpath(genpath(pwd));
run gen_param.m
max_iter=1;
param.nMC=100;
param.nM=100;
param.nT=20;
%% Initialize estimators
% This experiment mainly shows that as the 
estimator_list = {'FD2','AFD2','FD2_FV','AFD2_FV','EE','HM','SEQ_1','FD2_BEL','AFD2_BEL'};
statistic_list = {'average','bias','var','std','time','iter'};
norm_p=[];
norm_p_modified=[];

param_cell = {'$\theta_0^{VP,1}$', '$\theta_1^{VP,1}$', ...
    '$\theta_2^{VP,1}$','$\theta_0^{FC,1}$','$\theta_1^{FC,1}$',...
    '$\theta_0^{EC,1}$','$\theta_1^{EC,1}$','$\theta_0^{VP,2}$', '$\theta_1^{VP,2}$', ...
    '$\theta_2^{VP,2}$','$\theta_0^{FC,2}$','$\theta_1^{FC,2}$',...
    '$\theta_0^{EC,2}$','$\theta_1^{EC,2}$'};
%% Set theta list

theta_1 = theta; 
theta_1.VP0 = 1; 
theta_2 = theta; 
theta_2.VP0 = 0; 
theta_vec = [theta_to_vec(theta_1);theta_to_vec(theta_2)];
%parameters that determine the mixture
mix_param.nType = 2;
mix_param.mixProb = [0.5,0.5];
mix_param.theta_list = {theta_1,theta_2};
%%
for nGrid = [3,4]
    %%
    param.nGrid = nGrid;
    param.n_state = nGrid^5;
    
    for estimator = estimator_list
        for statistic = statistic_list
            eval([statistic{1} '_' estimator{1} '=[];']);
            eval([statistic{1} '_all=[];']);
        end
    end

    

    [F_struct,state] = DDCMixture.statetransition(param); %Generate
    
    if nGrid < 4
         p_star = solve_optimal_weight(param,F_struct);
    end
    
    param.P     = F_struct;
    param.state = state;
    param.n_action = 2;


    ts = tic;
    for i = 1: param.nMC
        [datasim.at,datasim.yt,datasim.zt] = ...
            DDCMixture.simdata_mix(param,mix_param);
        Data{i} = datasim;
    end
    TimeSimulation = toc(ts);
    fprintf('Simulation %d observations of mixture data used %f seconds \n', param.nMC ,TimeSimulation);

    theta_vec0 = zeros(7,1);
    p_default = zeros(param.n_state*param.n_action,1);

%%
    parfor i = 1:param.nMC
        opt = struct();
        fprintf('Estimating sample %d out of %d\n', i, param.nMC);
        datasim = Data{i};

        opt.true_ccp=0;
        %_____________________________________________________
        % EE
        ts = tic;
        opt.method = 'EE'; opt.max_iter=max_iter; %The sequential version
        [theta_hat_list,w,iter] = DDCMixture.SequentialEstimation(datasim,mix_param.nType,param,opt);
        if theta_hat_list{1}(1) >  theta_hat_list{2}(1)
            theta_hat = [theta_hat_list{1};theta_hat_list{2}];
        else
            theta_hat = [theta_hat_list{2};theta_hat_list{1}];
        end
        TimeEstimation =  toc(ts);
        ResultTable_EE(i,:) = theta_hat;
        IterTable_EE(i) = iter;
        TimeTable_EE(i) = TimeEstimation;    

        %_____________________________________________________
        % HM
        if nGrid < 5
            ts = tic;
            opt.method = 'HM'; opt.max_iter=max_iter; %The sequential version
            [theta_hat_list,w,iter] = DDCMixture.SequentialEstimation(datasim,mix_param.nType,param,opt);
            if theta_hat_list{1}(1) >  theta_hat_list{2}(1)
                theta_hat = [theta_hat_list{1};theta_hat_list{2}];
            else
                theta_hat = [theta_hat_list{2};theta_hat_list{1}];
            end
            TimeEstimation =  toc(ts);
            ResultTable_HM(i,:) = theta_hat;
            IterTable_HM(i) = iter;
            TimeTable_HM(i) = TimeEstimation;    
        else
            ResultTable_HM(i,:) = theta_vec;
            IterTable_HM(i) = 0;
            TimeTable_HM(i) = 0;    
        end
        %_____________________________________________________
        % FD2
        ts = tic;
        opt.method = 'FD2';opt.max_iter=max_iter;
        [theta_hat_list,w,iter] = DDCMixture.SequentialEstimation(datasim,mix_param.nType,param,opt,p_default);
        if theta_hat_list{1}(1) >  theta_hat_list{2}(1)
            theta_hat = [theta_hat_list{1};theta_hat_list{2}];
        else
            theta_hat = [theta_hat_list{2};theta_hat_list{1}];
        end
        TimeEstimation =  toc(ts);
        ResultTable_FD2(i,:) = theta_hat;
        IterTable_FD2(i) = iter;
        TimeTable_FD2(i) = TimeEstimation;    

        ts = tic;
        opt.method = 'FD2_FV';opt.max_iter=max_iter;
        [theta_hat_list,w,iter] = DDCMixture.SequentialEstimation(datasim,mix_param.nType,param,opt,p_default);
        if theta_hat_list{1}(1) >  theta_hat_list{2}(1)
            theta_hat = [theta_hat_list{1};theta_hat_list{2}];
        else
            theta_hat = [theta_hat_list{2};theta_hat_list{1}];
        end
        TimeEstimation =  toc(ts);
        ResultTable_FD2_FV(i,:) = theta_hat;
        IterTable_FD2_FV(i) = iter;
        TimeTable_FD2_FV(i) = TimeEstimation;    
        
        % The FD2/AFD2 estimator with bellman SEQ(1) update
        ts = tic;
        opt.method = 'FD2_BEL';opt.max_iter=max_iter;
        [theta_hat_list,w,iter] = DDCMixture.SequentialEstimation(datasim,mix_param.nType,param,opt,p_default);
        if theta_hat_list{1}(1) >  theta_hat_list{2}(1)
            theta_hat = [theta_hat_list{1};theta_hat_list{2}];
        else
            theta_hat = [theta_hat_list{2};theta_hat_list{1}];
        end
        TimeEstimation =  toc(ts);
        ResultTable_FD2_BEL(i,:) = theta_hat;
        IterTable_FD2_BEL(i) = iter;
        TimeTable_FD2_BEL(i) = TimeEstimation;  
        %_____________________________________________________
        % AFD2
        if nGrid < 4
            ts = tic;
            opt.method = 'FD2';opt.max_iter=max_iter;
            [theta_hat_list,w,iter] = DDCMixture.SequentialEstimation(datasim,mix_param.nType,param,opt,p_star);
            if theta_hat_list{1}(1) >  theta_hat_list{2}(1)
                theta_hat = [theta_hat_list{1};theta_hat_list{2}];
            else
                theta_hat = [theta_hat_list{2};theta_hat_list{1}];
            end
            TimeEstimation =  toc(ts);
            ResultTable_AFD2(i,:) = theta_hat;
            IterTable_AFD2(i) = iter;
            TimeTable_AFD2(i) = TimeEstimation;
            
            
            ts = tic;
            opt.method = 'FD2_FV';opt.max_iter=max_iter;
            [theta_hat_list,w,iter] = DDCMixture.SequentialEstimation(datasim,mix_param.nType,param,opt,p_star);
            if theta_hat_list{1}(1) >  theta_hat_list{2}(1)
                theta_hat = [theta_hat_list{1};theta_hat_list{2}];
            else
                theta_hat = [theta_hat_list{2};theta_hat_list{1}];
            end
            TimeEstimation =  toc(ts);
            ResultTable_AFD2_FV(i,:) = theta_hat;
            IterTable_AFD2_FV(i) = iter;
            TimeTable_AFD2_FV(i) = TimeEstimation;    

            ts = tic;
            opt.method = 'FD2_BEL';opt.max_iter=max_iter;
            [theta_hat_list,w,iter] = DDCMixture.SequentialEstimation(datasim,mix_param.nType,param,opt,p_star);
            if theta_hat_list{1}(1) >  theta_hat_list{2}(1)
                theta_hat = [theta_hat_list{1};theta_hat_list{2}];
            else
                theta_hat = [theta_hat_list{2};theta_hat_list{1}];
            end
            TimeEstimation =  toc(ts);
            ResultTable_AFD2_BEL(i,:) = theta_hat;
            IterTable_AFD2_BEL(i) = iter;
            TimeTable_AFD2_BEL(i) = TimeEstimation;  
            
        else
            ResultTable_AFD2(i,:) = theta_vec;
            IterTable_AFD2(i) = 0;
            TimeTable_AFD2(i) = 0;
            
            ResultTable_AFD2_FV(i,:) = theta_vec;
            IterTable_AFD2_FV(i) = 0;
            TimeTable_AFD2_FV(i) = 0;
            
            ResultTable_AFD2_BEL(i,:) = theta_vec;
            IterTable_AFD2_BEL(i) = 0;
            TimeTable_AFD2_BEL(i) = 0;
        end
        
        
        ts = tic;
        opt.method = 'SEQ_1'; opt.max_iter=max_iter; %The sequential version
        [theta_hat_list,w,iter] = DDCMixture.SequentialEstimation(datasim,mix_param.nType,param,opt);
        if theta_hat_list{1}(1) >  theta_hat_list{2}(1)
            theta_hat = [theta_hat_list{1};theta_hat_list{2}];
        else
            theta_hat = [theta_hat_list{2};theta_hat_list{1}];
        end
        TimeEstimation =  toc(ts);
        ResultTable_SEQ_1(i,:) = theta_hat;
        IterTable_SEQ_1(i) = iter;
        TimeTable_SEQ_1(i) = TimeEstimation;    

        
    end

    % Put into summary
    for estimator = estimator_list
        eval(['average_' estimator{1} '=[average_' estimator{1}  ' transpose(mean(ResultTable_' estimator{1} ' ))]; ']);
        eval(['bias_' estimator{1} '=[bias_' estimator{1}  ' transpose(abs(mean(ResultTable_' estimator{1} ' - transpose(theta_vec))))]; ']);
        eval(['var_' estimator{1} '=[var_' estimator{1}  ' transpose(var(ResultTable_' estimator{1} ' - transpose(theta_vec)))]; ']);
        eval(['std_' estimator{1} '=[std_' estimator{1}  ' transpose(std(ResultTable_' estimator{1} ' - transpose(theta_vec)))]; ']);
        eval(['time_' estimator{1} '=[time_' estimator{1}  ' transpose(TimeTable_' estimator{1} ')]; ']);
        eval(['iter_' estimator{1} '=[iter_' estimator{1}  ' transpose(IterTable_' estimator{1} ')]; ']);
    end

    % Diary Session
    diarystr = sprintf('diary/Table_mix_2_%d_M%d_T%d.txt',param.nGrid,param.nM,param.nT);
    delete(diarystr);
    diary(diarystr);
    disp(sprintf(['This experiment uses 2 step estimator to estimate a two-type mixture mode.'...
    'The size of the sample is N=%d, T=%d with %d Monte Carlo'...
    'Simulations.'],param.nM,param.nT,param.nMC  ));

    % Bias and Variance Table


    average_all = theta_vec;
    var_all=zeros(14,1);
    std_all=zeros(14,1);
    for estimator = estimator_list
    %     eval(['input.data  = bias_' estimator{1} ';']);
    %     eval(['input.variance= var_' estimator{1} ';']);
        eval(['average_all=[average_all,average_',estimator{1},'];']);
        eval(['var_all=[var_all,var_',estimator{1},'];']);
        eval(['std_all=[std_all,std_',estimator{1},'];']);
    end

    input.tableCaption = sprintf(['The mean and standard deviation of the estimators for  N=%d, T=%d with %d Monte Carlo '...
    'Simulations.'],param.nM,param.nT,param.nMC  );
    input.tableLabel=['mixture_1'];
    input.data = average_all;
    input.variance=std_all;
    input.tableRowLabels = param_cell;
    input.tableColLabels = ['DGP',estimator_list];
    latexVarianceTable(input);

    command_str_time = '[';command_str_iter = '[';
    for estimator = estimator_list
        command_str_time = [command_str_time '; median(time_',estimator{1},') '];
        command_str_iter = [command_str_iter '; median(iter_',estimator{1},') '];
    end
    command_str_time = [command_str_time ']'];command_str_iter = [command_str_iter ']'];

    input.data = eval(command_str_time);
    input.variance = eval(command_str_iter);
    input.tableColLabels = {'Two type mixture'};
    input.tableRowLabels = estimator_list;
    input.tableCaption = 'The median time used';
    latexVarianceTable(input);
    diary off;
end