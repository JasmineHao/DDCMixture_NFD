# DDCMixutre_linear
This repository is entry-exit dynamic decision model with linear payoff. The linear payoff combines with finite mixture model.
