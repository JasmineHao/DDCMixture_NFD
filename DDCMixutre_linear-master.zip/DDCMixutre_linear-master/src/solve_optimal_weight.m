function [w,iter,step_length,obj_init,obj_1]=solve_optimal_weight(param,F_struct)
    x_size=param.n_action*param.n_state;
    d_size=param.n_action-1;
    row_index=[];
    for k = 1:x_size
        for m = 1:d_size
            row_index = [row_index,(k-1)*(x_size*d_size) + (m-1)*x_size+k];
        end
    end

    %[F_struct,state] = DDCMixture.statetransition(param); %Generate
    F_0 = kron([0,1;0,1],F_struct{2});
    F_1 = kron([1,0;1,0],F_struct{1});
    F   = [F_0;F_1];    
    F_til = F_1 - F_0;

    a = F_til';
    b = F_til;
    nrow_b = size(b,2);
    A = [];

    for each_ind = row_index
        ind_b = rem(each_ind, nrow_b);
        if ind_b == 0
            ind_b = nrow_b;
            ind_a = floor(each_ind / nrow_b) ;
        else
            ind_a = floor(each_ind / nrow_b) + 1;
        end

        A = [A,kron(a(:,ind_a),b(:,ind_b) )];
    end
    
    b = (F_til*F_0); b = -b(:);
    
    step_length = 10; 
    max_iter=1000;tol=1e-4;
    w_0 = zeros(size(A,2),1); 
    obj_init = gradient_obj(A,b,w_0);
    obj_0 = obj_init; obj_init = sqrt(obj_init);
    iter=0;diff=1;
    while (iter < max_iter)&(diff>tol)
        w_1 = w_0 - step_length * gradient_linear(A,b,w_0);
        obj_1 = gradient_obj(A,b,w_1);
        while (obj_1 > obj_0) & (max(abs(w_1)) > 2)
            step_length = step_length/2;
            w_1 = w_0 - step_length * gradient_linear(A,b,w_0);
            obj_1 = gradient_obj(A,b,w_1);
        end
        w_0 = w_1;
        diff = abs(obj_1 - obj_0);
        obj_0 = obj_1;
        iter = iter+1;
    end
    w=w_1; obj_1 = sqrt(obj_1);
%     w = inv(A'*A) * A'* (-b);
end