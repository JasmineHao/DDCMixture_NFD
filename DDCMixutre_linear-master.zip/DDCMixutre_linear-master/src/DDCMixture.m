classdef DDCMixture
    methods (Static)
        function [P,state] = statetransition(param)
            %--------------------------------------------------------------
            % NFXP.statetransition
            % Input: param
            % Output:
            %         P:        n_state x n_state vector
            %                   state transition matrix
            %
            %         state:    n_state x dim(state)
            %                   define all possible states
            %--------------------------------------------------------------
            min_z = param.min_z;
            max_z = param.max_z;
            min_omega = param.min_omega;
            max_omega = param.max_omega;
            gam_z0 = param.gamma.z_0; %Parameters of z_j transition
            gam_z1 = param.gamma.z_1;
            gam_omega0 = param.gamma.omega_0; % Parameters of omega transition(productivity)
            gam_omega1 = param.gamma.omega_1;
            sigma_z = param.gamma.sigma_z;
            sigma_omega = param.gamma.sigma_omega;
            gamma_a = param.gamma.gamma_a;
            nGrid = param.nGrid;
            
            w_z = (max_z - min_z)/(nGrid - 1);
            w_omega = (max_omega - min_omega)/(nGrid - 1);
            z_grid = min_z : w_z : max_z;
            o_grid = min_omega : w_omega : max_omega;
            %--------------------------------------------------------------
            % f_z: transition density for z_j
            f_z = zeros(nGrid,nGrid);
            for i = 1 : nGrid
                for j = 1: nGrid
                    if j == 1
                        f_z(i,j) = normcdf((z_grid(j) + w_z / 2 - gam_z0 - ...
                            gam_z1 * z_grid(i))/sqrt(sigma_z));
                    elseif j == nGrid
                        f_z(i,j) = 1 - normcdf((z_grid(j) - w_z / 2 - gam_z0...
                            - gam_z1 * z_grid(i))/sqrt(sigma_z));
                    else
                        f_z(i,j) = normcdf((z_grid(j) + w_z / 2 - gam_z0 - ...
                            gam_z1 * z_grid(i))/sqrt(sigma_z)) - ...
                            normcdf((z_grid(j) - w_z / 2 - gam_z0 - ...
                            gam_z1 * z_grid(i) )/sqrt(sigma_z));
                    end
                end
            end
            %--------------------------------------------------------------
            % f_o: transition density for omega_j
            F_z = kron(f_z,kron(f_z,kron(f_z,f_z)));
            f_o = zeros(nGrid,nGrid);
            for k = 1:param.n_action
                a = param.a_space(k);
                for i = 1 : nGrid
                    for j = 1: nGrid
                        if j == 1
                            f_o(i,j) = normcdf((o_grid(j) + w_omega / 2 - gam_omega0 - ...
                                gam_omega1 * o_grid(i) - gamma_a * a )/sqrt(sigma_omega));
                        elseif j == nGrid
                            f_o(i,j) = 1 - normcdf((o_grid(j) - w_omega / 2 - gam_omega0...
                                - gam_omega1 * o_grid(i) - gamma_a * a)/sqrt(sigma_omega));
                        else
                            f_o(i,j) = normcdf((o_grid(j) + w_omega / 2 - gam_omega0 - ...
                                gam_omega1 * o_grid(i) - gamma_a * a)/sqrt(sigma_omega)) - ...
                                normcdf((o_grid(j) - w_omega / 2 - gam_omega0 - ...
                                gam_omega1 * o_grid(i) - gamma_a * a)/sqrt(sigma_omega));
                        end
                    end
                end
                P{k} = kron(F_z,f_o);
            end
            [tmp0, tmp1,tmp2,tmp3,tmp4] = ndgrid(o_grid,z_grid,z_grid,z_grid,z_grid);
            state = [tmp4(:),tmp3(:),tmp2(:),tmp1(:),tmp0(:)];
        end %end of state transition

        function [at,yt,zt] = simdata(theta_vec, S,nT,nM)
            %---------------------------------------------------------------------    
            % SYNTAX: [at,yt,zt,zt_1] = simdata(theta_vec, S,nT,nM)
            % INPUT: param
            %      P:   transition of exogenous data
            %      MC:  number of montecarlo
            %---------------------------------------------------------------------
            ev = zeros(S.n_state,S.n_action);
            pi = DDCMixture.dpidth(S) * theta_vec;
            [p1,ev] = DDCMixture.solveNFXP(ev,pi,S);
            n_state = S.n_state; %number of exogenous states
            p1 = reshape(p1,n_state,2);
            tmp11= S.P{1} .* repmat(p1(:,1),1,n_state); %y = 1, a = 1
            tmp10= S.P{2} .* repmat((1 - p1(:,1)),1,n_state); %y = 1, a = 0
            tmp01= S.P{1} .* repmat(p1(:,2),1,n_state);%y = 0, a = 1
            tmp00= S.P{2} .* repmat((1 - p1(:,2)),1,n_state);%y = 0, a = 0
            F_x  = [tmp11 , tmp10 ; tmp01, tmp00]; %joint transition of (y,z)
            % ---------------------------------------------------------------------
            %** Data structure
            %        at:     record  a_t for t=1:nT
            %        yt:     record  y_{t-1} for t=1:nT
            %        zt:     record  z_t for t=1:nT
            %        zt_1:   record  z_{t-1} for t=1:nT
            %---------------------------------------------------------------------
            at = zeros(nM, nT);
            yt = zeros(nM, nT);
            zt = zeros(nM, nT);
            zt_1 = zeros(nM, nT); %z t-1
            % ---------------------------------------------------------------------
            %** Create Markov Process of Exogeneous Variable
            % x_t = (y_t,z_t) 
            % need to simulate nT + 2 times
            % need a_t : t = 0 to nT
            %            y_t = a_t-1
            % need z_t : t = 0 to nT
            %---------------------------------------------------------------------
            x_mc  = dtmc(F_x); 
            
            for m = 1:nM
                   x_sim = simulate(x_mc,nT + 1);    
                   a     = floor((x_sim - 1) / n_state) + 1;
                   z     = rem(x_sim - 1, n_state)+1;
                   at(m,:) = a(2:nT+1);
                   yt(m,:) = a(1:nT);
                   zt(m,:) = z(1:nT);
                   
            end
        end
        
        function [at,yt,zt] = simdata_mix(param,mix_param)
            %---------------------------------------------------------------------    
            % SYNTAX: [at,yt,zt,zt_1] = simdata(P,state,p1, param)
            % INPUT: param
            %      P:   transition of exogenous data
            %      MC:  number of montecarlo
            %---------------------------------------------------------------------
            %Solve for type I and type II CCP
            %Simulate data
            %Generate mixture probabilities
            pd = makedist('Multinomial','probabilities',mix_param.mixProb); 
            ubs_type = random(pd,param.nM,1); %Simulated probatilities
            
            %---------------------------------------------------------------------
            %** Set parameters
            %---------------------------------------------------------------------
            at = []; yt=[];zt=[];
            for i = 1:mix_param.nType
                if isstruct(mix_param.theta_list{i})
                    theta_vec = theta_to_vec(mix_param.theta_list{i});
                else
                    theta_vec = mix_param.theta_list{i};
                end
                [at1,yt1,zt1] = DDCMixture.simdata(theta_vec,param,param.nT,...
                                 sum(ubs_type==i));
                at = [at;at1];
                yt = [yt;yt1];
                zt = [zt;zt1];
            end
        end %simdata_mix
        
        %---------------------------------------------------------------------    
      
        function [ll,ev,score] = ll(datasim,theta_vec,S)
            %[ll,ev,score] = DDCMixture.ll(datasim,theta_vec,S)
            
            % Log likelihood in NFXP
            % First solve for the equilibrium EV
            a = reshape(datasim.at,S.nM*S.nT,1);
            z = reshape(datasim.zt,S.nM*S.nT,1);
            y = reshape(datasim.yt,S.nM*S.nT,1);
            [ev,p1,F] = NFXP.solve(theta_vec,S);
            n_state = S.n_state;
            ind = (y - 1) * n_state + z ;
            data_p1 = p1(ind);

            ll  = (a==1).*log(data_p1) + (a==2).*log(1 - data_p1);
%             ll  = reshape(ll,S.nM,S.nT);
            %MULTIPLY THE WEIGHT HERE
%             ll  = reshape(ll,S.nM*S.nT,1);
            
            [devdth,dpidth] = DDCMixture.devdth(S,F,p1);
            % Step 4: Compute the derivative of log-likelihood w.r.nT theta
            score    = bsxfun(@times,( (a == 1) - p1(ind)) , dpidth(ind,:) +...
                      S.beta *  devdth(z,:));  
        end
        
        %---------------------------------------------------------------------    
        
        function [devdth,dpidth] = devdth(S,F,p1)
            % Compute score function
                n_state = S.n_state;
                ccp = reshape(p1,n_state,2);
                % Step 1: Compute the derivative of pi w.r.nT to mp
                dvpdth   = exp(S.state(:,5)).* [ones(n_state,1),S.state(:,1),S.state(:,2)]; %Derivative of variable profit
                dfcdth   = [ones(n_state,1),S.state(:,3)];% Derivative of fixed cost
                decdth   = [ones(n_state,1),S.state(:,4)];
                % Step 2: Compute the derivative of contraction mapping w.r.t mp
                dpidth_1 =  [dvpdth,-dfcdth,zeros(size(decdth))];
                dpidth_0 =  [dvpdth,-dfcdth,-decdth];
                dtdth_1  =  ccp(:,1) .* dpidth_1 ; %dpi/dtheta when y = 1
                dtdth_0  =  ccp(:,2) .* dpidth_0 ; %dpi/dtheta when y = 0
                dtdth    = [dtdth_1;dtdth_0];
                dpidth   = [dpidth_1;dpidth_0];

                % This is different than what I've seen, But I don't care 
                % Step 3: Compute the derivative of EV w.r.t theta
                dvdth   = F \ dtdth; 
                dvdth_1 = dvdth(1:n_state,:);
                dvdth_0 = dvdth((1+n_state):(2*n_state),:);
                devdth  = S.P * ( dvdth_1 - dvdth_0 );
        end
        
        function dpidth = dpidth(S)
            n_state = S.n_state;
                % Step 1: Compute the derivative of pi w.r.t to mp
                dvpdth   = exp(S.state(:,5)).* [ones(n_state,1),S.state(:,1),S.state(:,2)]; %Derivative of variable profit
                dfcdth   = [ones(n_state,1),S.state(:,3)];% Derivative of fixed cost
                decdth   = [ones(n_state,1),S.state(:,4)];
                % Step 2: Compute the derivative of contraction mapping w.r.t mp
                dpidth_1 =  [dvpdth,-dfcdth,zeros(size(decdth))];
                dpidth_0 =  [dvpdth,-dfcdth,-decdth];
                dpidth   = [dpidth_1;dpidth_0];
                
        end
    
        
        %------------------------------------------------------------------
        %*************      ESTIMATE DATA PROB         ********************
        %------------------------------------------------------------------
        
        %------------------------------------------------------------------
        %*************         GMM Estimator: ********************
        %*************         somehow it failed********************
        %------------------------------------------------------------------
        function p1 = gmm(datasim,S)
            eul = 0.5772156649015328606065120900824;
            %*************      ESTIMATE DATA PROB         ********************
            n_state = S.n_state;
            a = datasim.at(:);
            z = datasim.zt(:);
            y = datasim.yt(:);
            ind = (y - 1) * n_state + z ;
            freq_tab = crosstab(a,ind);
            p1 = min(max(freq_tab(1,:) ./ (sum(freq_tab,1)),1e-8),1- 1e-8);
            p1 = p1';
%             p1 = reshape(p1,n_state,2);
            
            F_size = size(S.P{2});
            F_1 = [S.P{1},zeros(F_size);S.P{1},zeros(F_size)];
            F_0 = [zeros(F_size),S.P{2};zeros(F_size),S.P{2}];
            F_opt = (eye(F_size(1)*2) - S.beta * F_1) * inv(eye(F_size(1)*2) - S.beta * F_0);
            RHS = F_opt * (eul - log(1 - p1(:))) + log(p1(:)) - eul ;
            LHS = DDCMixture.dpidth(S);
            X   = LHS(ind,:);
            Y   = RHS(ind);
            theta_hat = (X'*X)\(X'*Y);
        end
        %------------------------------------------------------------------
        %*************      Model Solving              ********************
        %------------------------------------------------------------------
         function [p1,ev] = mapping_seq(ev,pi,S)
            % Calculate ccp and ev based on sequential mapping
            beta = S.beta;
            P = S.P;
            ev = reshape(ev,size(P{1},2),2);
            pi = reshape(pi,size(P{1},2),2);
            eul = 0.5772156649015328606065120900824;
            v_til(:,1) =  pi(:,1) + beta *(P{1}*ev(:,1) - P{2}*ev(:,2)) ;
            v_til(:,2) =  pi(:,2) + beta *(P{1}*ev(:,1) - P{2}*ev(:,2));
            v_til = v_til(:);
            p1 = (exp(v_til) ./ (1 + exp(v_til)));

            tmp(:,1) = eul + log( exp( pi(:,1) + beta * P{1} * ( ev(:,1))) + exp( beta * P{2} *  ev(:,2))) ;
            tmp(:,2) = eul + log( exp( pi(:,2) + beta * P{1} * ( ev(:,1))) + exp( beta * P{2} *  ev(:,2))) ;
            ev = tmp;
        end
        
        
        function [p1,ev] = mapping_seq_ee(ev,pi,S)
            % Calculate ccp and ev based on sequential mapping
            beta = S.beta;
            P = S.P;
            ev = reshape(ev,size(P{1},2),2);
            pi = reshape(pi,size(P{1},2),2);
            eul = 0.5772156649015328606065120900824;
            v_til(:,1) =  pi(:,1) + beta *(P{1}*ev(:,1) - P{2}*ev(:,2));
            v_til(:,2) =  pi(:,2) + beta *(P{1}*ev(:,1) - P{2}*ev(:,2));
            p1 = (exp(v_til) ./ (1 + exp(v_til)));       
            tmp(:,1) = eul -  log( 1 - p1(:,1))  +  beta * P{2} *  ev(:,2) ;
            tmp(:,2) = eul -  log( 1 - p1(:,2))  +  beta * P{2} *  ev(:,2) ;
            p1 = p1(:);
            ev = tmp;
        end
        
        function [p1,ev] = solveNFXP(ev,pi,S)
            tol = 1e-8;
            diff = inf;
            max_iter = 3000;
            iter = 0;
            while (diff > tol) 
                [p1_1, ev_1] = DDCMixture.mapping_seq(ev,pi,S);
                diff = max(abs(ev_1 - ev));
                ev = ev_1;
                p1 = p1_1;
                iter = iter + 1;
                if (iter > max_iter)
                    break;
                end
            end
        end
        %------------------------------------------------------------------
        %*************      LIKELIHOOD FUNCTIONS       ********************
        %------------------------------------------------------------------
        function  V_star  =  map_EE(theta_vec,dpidth, p1, V_star,param,F_til,invF)
            % V_star is not used, just to keep all likelihood functions
            % consistent. See SequentialEstimation for details
%             pi_1       = dpidth * theta_vec ;
            % v_til_1 = pi_1 + param.beta * F_til * invF * (0.577215665 - log(1 - p1(:) ));
            V_star = invF * (0.5772156649015328606065120900824 - log(1 - p1(:)));
        end
        
        
        function V_star  =  map_HM(theta_vec,dpidth, p1, V_star, param,F_til,F_0)
            % V_star is not used, just to keep all likelihood functions
            % consistent. See SequentialEstimation for details
            eul = 0.5772156649015328606065120900824;
            %First update ccp with given theta and V
            pi_1       = dpidth * theta_vec;
            pi_P       = eul + ( pi_1 -  log(p1) ).*  p1 - log(1 - p1 ) .*(1- p1);
            F_P        = diag(p1) * F_til + F_0;
            invF       = inv(eye(size(F_P,2)) - param.beta * F_P);
            
            V_star = invF * (pi_P);
        end
        
        function V_star =  map_AFD2(theta_vec,dpidth, p1,V_star,w_star,param,F_1,F_0,F_til)
            % Update using finite dependence
            % The continuation value based on ccps
            pi =  dpidth * theta_vec;
            V1 = F_1 * V_star; V1 = param.beta*V1;V1 = V1 + pi; V1 =V1-log(p1);
            
            V0 = F_0 * V_star; V0 = param.beta*V0;
            V0 = - log(1-p1) + V0;
            V_star = 0.5772156649015328606065120900824 + w_star .* V1 + (1 - w_star).* V0;            
        end
        
        function V_star = map_FD2(theta_vec,dpidth, p1,V_star,w_star,param,F_1,F_0,F_til)
%             V_star = 0.5772156649015328606065120900824 - log(1-p1) + param.beta * F_0 * V_star;        
               V_star1 = F_0 * V_star; 
               V_star1 = V_star1 * param.beta; 
               V_star1 = V_star1 + 0.5772156649015328606065120900824; 
               V_star1 = V_star1 - log(1-p1);
               V_star = V_star1;
        end
          
        
        function V_star =  map_SEQ(theta_vec,dpidth, p1, V_star,param,F_1,F_0,q)
            % Update using finite dependence
            % The continuation value based on ccps
            pi =  dpidth * theta_vec;
            for ii = 1:q
                V_star = DDCMixture.bellman(V_star,pi,F_1,F_0,param.beta);
            end
        end
        
        function p1 = update_P(theta_vec,dpidth, V_star,param,F_til)
            pi_1  = dpidth * theta_vec;
            v_til_1 = pi_1 + param.beta * F_til * V_star;
            p1 = exp(v_til_1) ./ (1 + exp(v_til_1));
        end
        
        %------------------------------------------------------------------
        %Let the objective function be logit like function, maximize
        %sum_it Lambda(a_it*theta + b), where Lambda(x) = exp(x) / 1 +
        %exp(x)
        %------------------------------------------------------------------
   
        function [ll_sum,lik] = lin_objective(theta_vec,A,B,w,nM,nT)
            tmp = exp( A * theta_vec + B);
            tmp = log(tmp ./ (1+tmp));
            ll_weight = w.* sum(reshape(tmp,nM,nT),2);
            ll_sum = sum(ll_weight);
            if nargout > 1
                lik = sum(reshape(tmp,nM,nT),2);
            end
        end
        
        %This A function can be used as SEQ estimation
        function A = lin_comp_A(dpidth,ind2)
            A = [dpidth;-dpidth];
            A = A(ind2,:);
        end
        function B = lin_comp_B(V_star,F_til,ind2,beta)
            B = beta * [F_til*V_star; - F_til*V_star];
            B = B(ind2,:);
        end
                
        function A = lin_comp_FD_A(dpidth,w_star,F_til,ind2,beta)
            A = [dpidth + beta * F_til * diag(w_star)*dpidth ;- dpidth - beta * F_til * diag(w_star)*dpidth];
            A = A(ind2,:);
        end
        
        function B = lin_comp_FD_B(p1,V_star,w_star,F_til,F_0,ind2,beta)
            eul = 0.5772156649015328606065120900824;
            F_1 = F_til + F_0;
            e1 =  - log(p1) + beta * F_1 * V_star;
            e0 =  - log(1-p1) + beta * F_0 * V_star;
            V_star_1 = eul + w_star .* e1 + (1 - w_star).* e0;
            B = beta * [F_til*V_star_1; - F_til*V_star_1];
            B = B(ind2,:);
        end
        
        function [A,B] = lin_comp_HM(dpidth,ind2,p1,F_til,F_0,beta)
            eul = 0.5772156649015328606065120900824;
            e_P       = eul - p1 .* log(p1) - log(1 - p1 ) .*(1- p1);
            F_P        = diag(p1) * F_til + F_0;
            invF       = inv(eye(size(F_P,2)) - beta * F_P);
            A = [dpidth + beta * F_til * invF * diag(p1)*dpidth;-dpidth - beta * F_til * invF * diag(p1)*dpidth];
            B = [ beta * F_til * invF * e_P; - beta * F_til * invF * e_P];
            A = A(ind2,:);
            B = B(ind2,:);
        end
        
        function [A,B] = lin_comp_AFD(dpidth,ind2,w_star,V_star,p1,F_til,F_0,beta)
            eul = 0.5772156649015328606065120900824;
            e_P    = eul - w_star .* log(p1) - log(1 - w_star ) .*(1- p1);
            F_P    = diag(w_star) * F_til + F_0;
            V_P    = e_P + beta * F_P * V_star;
            A = [dpidth + beta * F_til *  diag(w_star) * dpidth; -dpidth - beta * F_til *  diag(w_star) * dpidth];
            B = [ beta * F_til * V_P ; - beta * F_til * V_P];
            A = A(ind2,:);
            B = B(ind2,:);
        end
        
        %------------------------------------------------------------------
        % **************      MIXTURE ESTIMATION          *****************
        % Estimate several type mixture model
        %------------------------------------------------------------------

        function [theta_hat_list,w1,iter] = SequentialEstimation(datasim,nType,param,opt,w_star)
            o1 = optimset('LargeScale','off','Display','off');
            o2 = optimset('LargeScale','off','Display','off','GradObj','on');
            
            %STEP 1: guess the weight for the two type mixture
            %_________________________________________________
            w0 = rand(size(datasim.at,1),nType);
            w0 = w0 ./ repmat(sum(w0,2),1,2);
            q = mean(w0); 
            opt.tol  = 1e-6;
            opt.tol_r= 1e-3;
            opt.max_iter = 500;
            opt.output = 0;
            diff      = 1;
            iter      = 0;
            theta_vec0 = zeros(7,1);
            p1 = DDCMixture.estimate_ccp(datasim,param); %The initial CCP
            V_star = zeros(param.n_action * param.n_state,1);
            for i = 1:nType
                theta_hat_list{i} = theta_vec0;
                p_list{i} = p1;
                V_list{i} = V_star;
            end
                     
            % F_star = diag(w_star) * F_til + F_0;
                
            %STEP 2: Estimate the CCPs from Data
            %_________________________________________________
            a = reshape(datasim.at,param.nM*param.nT,1);
            z = reshape(datasim.zt,param.nM*param.nT,1);
            y = reshape(datasim.yt,param.nM*param.nT,1);
            a = a(:);
            [n_state,d_state] = size(param.state);
            n_action = param.n_action;
            ind  =  (y - 1) * n_state + z ;
            ind2 =(a - 1) * n_state * n_action + (y - 1) * n_state + z ;
            dpidth  = DDCMixture.dpidth(param); %The [d pi/d theta ] matrix
            % W_u =  dpidth(ind,:) ; %W_u contains the observable matrix
            
            F_0 = kron([0,1;0,1],param.P{2});
            F_1 = kron([1,0;1,0],param.P{1});
            F_til = F_1 - F_0; 
            
            %STEP 3.1: Select estimation method
            %_________________________________________________
            if string(opt.method) == 'FD2'
                A_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_FD_A(dpidth,w_star,F_til,ind2,beta)); 
                B_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_FD_B(p1,V_star,w_star,F_til,F_0,ind2,beta));
%                 A_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_A(dpidth,ind2)); 
%                 B_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_B(V_star,F_til,ind2,param.beta));
                 
                update_A = 0;
                update_B = 1;
                update_P = 1;
                map_func   = @(theta_vec, p1,V_star) (DDCMixture.map_FD2(theta_vec,dpidth, p1,V_star,w_star,param,F_1,F_0,F_til));
                size_n_state = param.n_state * param.n_action;
                V_star = zeros(size_n_state,1);
                A = A_function(dpidth,ind2,V_star,p1,F_til,param.beta); 
                B = B_function(dpidth,ind2,V_star,p1,F_til,param.beta);
                    
                f = @(theta_vec) -DDCMixture.lin_objective(theta_vec,A,B,ones(param.nM,1),param.nM,param.nT);
                theta_vec = fmincon(f,theta_vec0,[],[],[],[],[],[],[],o1);
                if opt.output > 0
                    fprintf('Iteration: %d, Difference: %.4f, Time elapsed: %f Seconds \n',iter,diff,Result.REALtime);
                end
                
                pi_1  = DDCMixture.dpidth(param) * theta_vec;
                for q = 1:10
                    V_star = DDCMixture.bellman_fd(V_star,pi_1,p1,w_star,F_1,F_0,param.beta);
                end
                for m = 1:nType
                    V_list{m} = V_star;
                    A = A_function(dpidth,ind2,V_list{m},p_list{m},F_til,param.beta); 
                    B = B_function(dpidth,ind2,V_list{m},p_list{m},F_til,param.beta);
                    A_list{m} = A; 
                    B_list{m} = B;
                end
                if max(abs(w_star)) == 0
                    map_func   = @(theta_vec, p1,V_star) (DDCMixture.map_FD2(theta_vec,dpidth, p1,V_star,w_star,param,F_1,F_0,F_til));
                else
                    map_func   = @(theta_vec, p1,V_star) (DDCMixture.map_AFD2(theta_vec,dpidth, p1,V_star,w_star,param,F_1,F_0,F_til));
                end
            
            elseif string(opt.method) == 'FD2_BEL'
                A_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_FD_A(dpidth,w_star,F_til,ind2,beta)); 
                B_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_FD_B(p1,V_star,w_star,F_til,F_0,ind2,beta));

                update_A = 0;
                update_B = 1;
                update_P = 1;
                
                size_n_state = param.n_state * param.n_action;
                V_star = zeros(size_n_state,1);
                A = A_function(dpidth,ind2,V_star,p1,F_til,param.beta); 
                B = B_function(dpidth,ind2,V_star,p1,F_til,param.beta);
                
                map_func = @(theta_vec,p1,V_star) (DDCMixture.map_SEQ(theta_vec,dpidth,p1,V_star,param,F_1,F_0,1));                
                    
                f = @(theta_vec) -DDCMixture.lin_objective(theta_vec,A,B,ones(param.nM,1),param.nM,param.nT);
                theta_vec = fmincon(f,theta_vec0,[],[],[],[],[],[],[],o1);
                if opt.output > 0
                    fprintf('Iteration: %d, Difference: %.4f, Time elapsed: %f Seconds \n',iter,diff,Result.REALtime);
                end
                
%                 pi_1  = DDCMixture.dpidth(param) * theta_vec;
                for q = 1:10
                    V_star = map_func(theta_vec,p1,V_star);
                end
                for m = 1:nType
                    V_list{m} = V_star;
                    A = A_function(dpidth,ind2,V_list{m},p_list{m},F_til,param.beta); 
                    B = B_function(dpidth,ind2,V_list{m},p_list{m},F_til,param.beta);
                    A_list{m} = A; 
                    B_list{m} = B;
                end
                
            elseif string(opt.method) == 'FD2_FV'
                A_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_FD_A(dpidth,w_star,F_til,ind2,beta)); 
                B_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_FD_B(p1,V_star,w_star,F_til,F_0,ind2,beta));
                
                update_A = 0;
                update_B = 1;
                update_P = 1;
                map_func   = @(theta_vec, p1,V_star) (DDCMixture.map_FD2(theta_vec,dpidth, p1,V_star,w_star,param,F_1,F_0,F_til));
                size_n_state = param.n_state * param.n_action;
                V_star = zeros(size_n_state,1);
                
                A = A_function(dpidth,ind2,V_star,p1,F_til,param.beta); 
                B = B_function(dpidth,ind2,V_star,p1,F_til,param.beta);
                    
                f = @(theta_vec) -DDCMixture.lin_objective(theta_vec,A,B,ones(param.nM,1),param.nM,param.nT);
                theta_vec = fmincon(f,theta_vec0,[],[],[],[],[],[],[],o1);
                if opt.output > 0
                    fprintf('Iteration: %d, Difference: %.4f, Time elapsed: %f Seconds \n',iter,diff,Result.REALtime);
                end
                
                pi_1  = DDCMixture.dpidth(param) * theta_vec;
                for q = 1:10
                    V_star = DDCMixture.bellman_fd(V_star,pi_1,p1,w_star,F_1,F_0,param.beta);
                end
                for m = 1:nType
                    V_list{m} = V_star;
                    A = A_function(dpidth,ind2,V_list{m},p_list{m},F_til,param.beta); 
                    B = B_function(dpidth,ind2,V_list{m},p_list{m},F_til,param.beta);
                    A_list{m} = A; 
                    B_list{m} = B;
                end
                map_func   = @(theta_vec, p1,V_star) (DDCMixture.map_FD2(theta_vec,dpidth, p1,V_star,w_star,param,F_1,F_0,F_til));

            elseif string(opt.method) == 'EE'   
                A_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_A(dpidth,ind2)); 
                B_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_B(V_star,F_til,ind2,param.beta));
                
                update_A = 0;
                update_B = 1;
                update_P = 1;
                size_n_state = param.n_state * param.n_action;
                invF =  inv(eye(size_n_state) - param.beta * F_0);
                map_func   = @(theta_vec, p1,V_star) (DDCMixture.map_EE(theta_vec,dpidth, p1, V_star, param,F_til,invF));
                
                V_star = invF * (0.5772156649015328606065120900824 - log(1 - p1(:)));
                for m = 1:nType
                    V_list{m} = V_star;
                    A_list{m} = A_function(dpidth,ind2,V_list{m},p_list{m},F_til,param.beta); 
                    B_list{m} = B_function(dpidth,ind2,V_list{m},p_list{m},F_til,param.beta);
                end
            elseif string(opt.method) == 'HM'
                %Solve initial CCP  
                [A,B] = DDCMixture.lin_comp_HM(dpidth,ind2,p1,F_til,F_0,param.beta);
                AB_function = @(dpidth,ind2,p1,V_star,F_til,F_0,beta) (DDCMixture.lin_comp_HM(dpidth,ind2,p1,F_til,F_0,param.beta)); 
                for m = 1:nType
                    A_list{m} = A; 
                    B_list{m} = B;
                end
                update_A = 1;
                update_B = 1;
                update_P = 1;
                map_func   = @(theta_vec, p1,V_star) (DDCMixture.map_HM(theta_vec,dpidth,p1, V_star, param,F_til,F_0));
            elseif length(strsplit(opt.method,'_')) > 1
                method_list = strsplit(opt.method,'_');
                if ~strcmp(method_list{1}, 'SEQ')
                    fprintf('Incorrect method, use SEQ bellman to update');
                end
                A_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_A(dpidth,ind2)); 
                B_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_B(V_star,F_til,ind2,param.beta));
                for m = 1:nType
                    A_list{m} = A_function(dpidth,ind2,V_list{m},p_list{m},F_til,param.beta); 
                    B_list{m} = B_function(dpidth,ind2,V_list{m},p_list{m},F_til,param.beta);
                end
                q = str2num(method_list{2});
                update_A = 0;
                update_B = 1;
                update_P = 0;
                map_func = @(theta_vec,p1,V_star) (DDCMixture.map_SEQ(theta_vec,dpidth,p1,V_star,param,F_1,F_0,q));                
            else
                fprintf('No correct algorithm chosen\n');
            end
            %STEP 3.2: Sequential estimation
            %_________________________________________________
            diff = 1; ll_0 = 0; w1 = w0;
            diff_r = 1;
                
            while ((diff > opt.tol) & (diff_r > opt.tol_r) & (iter < opt.max_iter))
                % w = w0;
                q = mean(w0); 
                for m = 1:nType
                    
                    A = A_list{m}; B = B_list{m};
                    f = @(theta_vec) -DDCMixture.lin_objective(theta_vec,A,B,w0(:,m),param.nM,param.nT);
                    theta_m = fmincon(f,theta_vec0,[],[],[],[],[],[],[],o1);
                    [ll,logl] = DDCMixture.lin_objective(theta_m,A,B,ones(param.nM,1),param.nM,param.nT);
                    p1 = p_list{m};
                    V_star = V_list{m};
                    if update_P
                        p1 = DDCMixture.update_P(theta_m,dpidth, V_star,param,F_til);
                        p_list{m} = p1; 
                    end
                    if (string(opt.method) ~= 'FD2_FV' )
                        V_star = map_func(theta_m,p1,V_star);
                        V_list{m} = V_star;
                    end
                    if (update_A) & (~update_B)
                        A_list{m} = A_function(dpidth,ind2,V_star,p1,F_til,param.beta);
                    elseif (~update_A) & (update_B)
                        B_list{m} = B_function(dpidth,ind2,V_star,p1,F_til,param.beta);
                    elseif (update_A) & (update_B)
                       [A,B] = AB_function(dpidth,ind2,p1,V_star,F_til,F_0,param.beta);
                       A_list{m} = A; B_list{m} = B;
                    end
                    logl_mat(:,m) = logl; theta_hat_list{m}=theta_m;
                end
                minl = min(min(logl_mat));
                for m = 1:nType
                    w(:,m) = (q(m) * exp(logl_mat(:,m) - minl) );
                end
                w = w ./sum(w,2);
                ll = -sum( log(sum(w,2)) + minl );
%                 w = q.*logl_mat;
%                 ll = -sum(sum(w,2));
                w0 = w./repmat(sum(w,2),1,nType);
                diff = abs(ll_0 - ll);
%                 diff_r = abs(ll_0 - ll) / abs(ll_0);
                ll_0 = ll;
                w1 = w0;
                iter = iter+1;
            end
            
        end %End of Mixture.sequential_EE

        
        %------------------------------------------------------------------
        % **************                                  *****************
        % **************      Single Type Estimation      *****************
        % **************                                  *****************
        %------------------------------------------------------------------
        function [theta_hat,iter] = SingleEstimation(datasim,param,opt,w_star)
            o1 = optimset('LargeScale','off','Display','off','TolFun',1e-16,'TolX',1e-16);
            o2 = optimset('LargeScale','off','Display','off','GradObj','on');
            
            %STEP 1: guess the weight for the two type mixture
            %_________________________________________________
            
            opt.tol  = 1e-6;
            if ~ isfield(opt,'max_iter')
                opt.max_iter = 1000;
            end
            
            opt.output = 0;
            diff      = 1;
            iter      = 0;
            theta_vec0 = zeros(7,1);
            if opt.true_ccp 
                p1 = param.p_1;
            else
                p1 = DDCMixture.estimate_ccp(datasim,param); %The initial CCP
            end
            V_star = zeros(param.n_action * param.n_state,1);
                     
            % F_star = diag(w_star) * F_til + F_0;
                
            %STEP 2: Estimate the CCPs from Data
            %_________________________________________________
            a = reshape(datasim.at,param.nM*param.nT,1);
            z = reshape(datasim.zt,param.nM*param.nT,1);
            y = reshape(datasim.yt,param.nM*param.nT,1);
            [n_state,d_state] = size(param.state);
            n_action = param.n_action;
            ind  =  (y - 1) * n_state + z ;
            ind2 =(a - 1) * n_state * n_action + (y - 1) * n_state + z ;
            dpidth  = DDCMixture.dpidth(param); %The [d pi/d theta ] matrix
            % W_u =  dpidth(ind,:) ; %W_u contains the observable matrix
            
            F_0 = kron([0,1;0,1],param.P{2});
            F_1 = kron([1,0;1,0],param.P{1});
            F_til = F_1 - F_0; 
            
            %STEP 3.1: Select estimation method
            %_________________________________________________
            if string(opt.method) == 'FD2'
                A_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_FD_A(dpidth,w_star,F_til,ind2,beta)); 
                B_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_FD_B(p1,V_star,w_star,F_til,F_0,ind2,beta));
%                 A_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_A(dpidth,ind2)); 
%                 B_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_B(V_star,F_til,ind2,param.beta));
            
                update_A = 0;
                update_B = 1;
                update_P = 1;
                map_func   = @(theta_vec, p1,V_star) (DDCMixture.map_FD2(theta_vec,dpidth, p1,V_star,w_star,param,F_1,F_0,F_til));
                size_n_state = param.n_state * param.n_action;
                V_star = zeros(size_n_state,1);
                
                
                A = A_function(dpidth,ind2,V_star,p1,F_til,param.beta); 
                B = B_function(dpidth,ind2,V_star,p1,F_til,param.beta);
                    
                f = @(theta_vec) -DDCMixture.lin_objective(theta_vec,A,B,ones(param.nM,1),param.nM,param.nT);
                theta_vec = fmincon(f,theta_vec0,[],[],[],[],[],[],[],o1);
                if opt.output > 0
                    fprintf('Iteration: %d, Difference: %.4f, Time elapsed: %f Seconds \n',iter,diff,Result.REALtime);
                end
                
                pi_1  = DDCMixture.dpidth(param) * theta_vec;
                for q = 1:10
                    V_star = DDCMixture.bellman_fd(V_star,pi_1,p1,w_star,F_1,F_0,param.beta);
                end
                A = A_function(dpidth,ind2,V_star,p1,F_til,param.beta); 
                B = B_function(dpidth,ind2,V_star,p1,F_til,param.beta);
                if (max(abs(w_star)) == 0)
                    map_func   = @(theta_vec, p1,V_star) (DDCMixture.map_FD2(theta_vec,dpidth, p1,V_star,w_star,param,F_1,F_0,F_til));
                else 
                    map_func   = @(theta_vec, p1,V_star) (DDCMixture.map_AFD2(theta_vec,dpidth, p1,V_star,w_star,param,F_1,F_0,F_til));
                end
            elseif string(opt.method) =='FD2_BEL'
                A_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_FD_A(dpidth,w_star,F_til,ind2,beta)); 
                B_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_FD_B(p1,V_star,w_star,F_til,F_0,ind2,beta));

                update_A = 0;
                update_B = 1;
                update_P = 1;
                
                size_n_state = param.n_state * param.n_action;
                V_star = zeros(size_n_state,1);
                A = A_function(dpidth,ind2,V_star,p1,F_til,param.beta); 
                B = B_function(dpidth,ind2,V_star,p1,F_til,param.beta);
                
                map_func = @(theta_vec,p1,V_star) (DDCMixture.map_SEQ(theta_vec,dpidth,p1,V_star,param,F_1,F_0,1));                
                    
                f = @(theta_vec) -DDCMixture.lin_objective(theta_vec,A,B,ones(param.nM,1),param.nM,param.nT);
                theta_vec = fmincon(f,theta_vec0,[],[],[],[],[],[],[],o1);
                if opt.output > 0
                    fprintf('Iteration: %d, Difference: %.4f, Time elapsed: %f Seconds \n',iter,diff,Result.REALtime);
                end
                
%                 pi_1  = DDCMixture.dpidth(param) * theta_vec;
                for q = 1:10
                    V_star = map_func(theta_vec,p1,V_star);
                end
                A = A_function(dpidth,ind2,V_star,p1,F_til,param.beta); 
                B = B_function(dpidth,ind2,V_star,p1,F_til,param.beta);
                map_func = @(theta_vec,p1,V_star) (DDCMixture.map_SEQ(theta_vec,dpidth,p1,V_star,param,F_1,F_0,1));                
                
            elseif string(opt.method) == 'FD2_FV'
                A_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_FD_A(dpidth,w_star,F_til,ind2,beta)); 
                B_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_FD_B(p1,V_star,w_star,F_til,F_0,ind2,beta));
%                 A_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_A(dpidth,ind2)); 
%                 B_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_B(V_star,F_til,ind2,param.beta));
            
                update_A = 0;
                update_B = 1;
                update_P = 1;
                map_func   = @(theta_vec, p1,V_star) (DDCMixture.map_FD2(theta_vec,dpidth, p1,V_star,w_star,param,F_1,F_0,F_til));
                size_n_state = param.n_state * param.n_action;
                V_star = zeros(size_n_state,1);
                
                
                A = A_function(dpidth,ind2,V_star,p1,F_til,param.beta); 
                B = B_function(dpidth,ind2,V_star,p1,F_til,param.beta);
                    
                f = @(theta_vec) -DDCMixture.lin_objective(theta_vec,A,B,ones(param.nM,1),param.nM,param.nT);
                theta_vec = fmincon(f,theta_vec0,[],[],[],[],[],[],[],o1);
                if opt.output > 0
                    fprintf('Iteration: %d, Difference: %.4f, Time elapsed: %f Seconds \n',iter,diff,Result.REALtime);
                end
                
                pi_1  = DDCMixture.dpidth(param) * theta_vec;
                for q = 1:10
                    V_star = DDCMixture.bellman_fd(V_star,pi_1,p1,w_star,F_1,F_0,param.beta);
                end
                A = A_function(dpidth,ind2,V_star,p1,F_til,param.beta); 
                B = B_function(dpidth,ind2,V_star,p1,F_til,param.beta);
                map_func   = @(theta_vec, p1,V_star) (DDCMixture.map_FD2(theta_vec,dpidth, p1,V_star,w_star,param,F_1,F_0,F_til));
            
            elseif string(opt.method) == 'FD'
                A_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_FD_A(dpidth,w_star,F_til,ind2,beta)); 
                B_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_FD_B(p1,V_star,w_star,F_til,F_0,ind2,beta));
%                 A_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_A(dpidth,ind2)); 
%                 B_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_B(V_star,F_til,ind2,param.beta));
                A = A_function(dpidth,ind2,V_star,p1,F_til,param.beta); 
                B = B_function(dpidth,ind2,V_star,p1,F_til,param.beta);
                update_A = 0;
                update_B = 1;
                update_P = 1;
                map_func   = @DDCMixture.map_FD_s;
                F_size = size(param.P{2});
                size_n_state = param.n_state * param.n_action;
                V_star = zeros(size_n_state,1);
                map_func   = @(theta_vec, p1,V_star) (DDCMixture.map_FD2(theta_vec,dpidth, p1,V_star,w_star,param,F_1,F_0,F_til));
            
            elseif string(opt.method) == 'EE'   
                A_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_A(dpidth,ind2)); 
                B_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_B(V_star,F_til,ind2,param.beta));
            
                update_A = 0;
                update_B = 1;
                update_P = 1;
                size_n_state = param.n_state * param.n_action;
                invF =  inv(eye(size_n_state) - param.beta * F_0);
                V_star = invF * (0.5772156649015328606065120900824 - log(1 - p1(:)));
                A = A_function(dpidth,ind2,V_star,p1,F_til,param.beta); 
                B = B_function(dpidth,ind2,V_star,p1,F_til,param.beta);
                map_func   = @(theta_vec, p1,V_star) (DDCMixture.map_EE(theta_vec,dpidth, p1, V_star, param,F_til,invF));
            elseif string(opt.method) == 'HM'
                %Solve initial CCP  
                [A,B] = DDCMixture.lin_comp_HM(dpidth,ind2,p1,F_til,F_0,param.beta);
                AB_function = @(dpidth,ind2,p1,V_star,F_til,F_0,beta) (DDCMixture.lin_comp_HM(dpidth,ind2,p1,F_til,F_0,param.beta)); 
                
                update_A = 1;
                update_B = 1;
                update_P = 1;
                map_func   = @(theta_vec, p1,V_star) (DDCMixture.map_HM(theta_vec,dpidth,p1, V_star, param,F_til,F_0));
            elseif length(strsplit(opt.method,'_')) > 1
                method_list = strsplit(opt.method,'_');
                if ~strcmp(method_list{1}, 'SEQ')
                    fprintf('Incorrect method, use SEQ bellman to update');
                end
                A_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_A(dpidth,ind2)); 
                B_function = @(dpidth,ind2,V_star,p1,F_til,beta) (DDCMixture.lin_comp_B(V_star,F_til,ind2,param.beta));
                A = A_function(dpidth,ind2,V_star,p1,F_til,param.beta); 
                B = B_function(dpidth,ind2,V_star,p1,F_til,param.beta);
                q = str2num(method_list{2});
                update_A = 0;
                update_B = 1;
                update_P = 0;
                map_func = @(theta_vec,p1,V_star) (DDCMixture.map_SEQ(theta_vec,dpidth,p1,V_star,param,F_1,F_0,q));                
            else
                fprintf('No correct algorithm chosen\n');
            end
            %STEP 3.2: Sequential estimation
            %_________________________________________________
            diff = 1; ll_0 = 0; 
            
                
            while ((diff > opt.tol) & (iter < opt.max_iter) )
                f = @(theta_vec) -DDCMixture.lin_objective(theta_vec,A,B,ones(param.nM,1),param.nM,param.nT);
                theta_hat = fmincon(f,theta_vec0,[],[],[],[],[],[],[],o1);
                [ll,logl] = DDCMixture.lin_objective(theta_hat,A,B,ones(param.nM,1),param.nM,param.nT);
                
                if update_P
                    p1 = DDCMixture.update_P(theta_hat,dpidth, V_star,param,F_til);
                end
                if (string(opt.method) ~= 'FD2_FV' ) & (string(opt.method) ~= 'FD' )
                    V_star = map_func(theta_hat,p1,V_star);
                end

                if (update_A) & (~update_B)
                    A = A_function(dpidth,ind2,V_star,p1,F_til,param.beta);
                elseif (~update_A) & (update_B)
                    B = B_function(dpidth,ind2,V_star,p1,F_til,param.beta);
                elseif (update_A) & (update_B)
                   [A,B] = AB_function(dpidth,ind2,p1,V_star,F_til,F_0,param.beta);
                end
                
                diff = abs(ll_0 - ll);
                ll_0 = ll;
                iter = iter+1;
            end
            
        end %End of Mixture.SingleEstimation
        
        %------------------------------------------------------------------
        % **************      Estimation *****************
        %------------------------------------------------------------------
        
        function p1 = estimate_ccp(datasim,param)
            %p1 = [p(1|z,1),p(1|z,0)]
            a = datasim.at(:);
            z = datasim.zt(:);
            y = datasim.yt(:);
            ind = (y - 1) *param.n_state + z;
            max_ind = param.n_action * param.n_state;
            for each_ind = 1:max_ind 
                subset_ind = (ind == each_ind);
                if sum(subset_ind) > 0
                    p1(each_ind) = mean(a(subset_ind)==1);
                    if p1(each_ind)==0
                        p1(each_ind) = 1/length(a);
                    elseif p1(each_ind)==1
                        p1(each_ind) = 1-1/length(a);
                    end
                else 
                    p1(each_ind) = 1/length(a);
                end
            end
            p1 = vec(p1);
        end
        
        function V = bellman(V_star,pi,F_1,F_0,beta)
            eul = 0.5772156649015328606065120900824;
            v_1 = pi + beta * F_1 * V_star;
            v_0 = beta * F_0 * V_star;
            V = eul + log(exp(v_1) + exp(v_0));
        end
        function V = bellman_ee(V_star,pi,p1,F_1,F_0,beta)
         	V = p1 .* (pi - log(p1) + beta  * F_1 * V_star) + (1-p1).* ( beta  * F_0 * V_star - log(1-p1)) + 0.577215665;
        end
        
        function V = bellman_fd(V_star, pi,p1,w_star,F_1,F_0,beta)
            V1 = 0.5772156649015328606065120900824 + pi - log(p1) + beta * F_1 * V_star;
            V0 = 0.5772156649015328606065120900824 - log(1-p1) + beta * F_0 * V_star;
            V = w_star .* V1 + (1 - w_star).* V0;
        end

        
        

    end
end 