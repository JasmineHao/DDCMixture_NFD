function nabla_obj = gradient_linear(A,b,w)
    nabla_obj = 2 * A'*(A * w - b);
end