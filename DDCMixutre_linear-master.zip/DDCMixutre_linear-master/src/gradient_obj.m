function obj = gradient_obj(A,b,w)
    tmp=(A * w - b);
    obj = tmp'*tmp;
end