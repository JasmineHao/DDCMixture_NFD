run script_experiment_1.m
run script_experiment_1_seq.m
run script_experiment_mix_2type_1.m
run script_experiment_mix_2type_2.m
run script_experiment_mix_2type_3.m

%%
run script_experiment_2.m
run script_experiment_2_seq.m
%%
run script_experiment_3.m

