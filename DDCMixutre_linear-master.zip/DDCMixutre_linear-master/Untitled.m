clear all;
if ~exist("conAssign")
    run C:\tomlab\startup.m
else
    disp("TomLab Initiated");
end
addpath(genpath(pwd));
run gen_param.m
max_iter=1000;
param.nMC=100;
param.nT=120;
% Initialize estimators
% This experiment mainly shows that as the 
estimator_list = {'FD','FD2','AFD','AFD2','FD2_BEL','AFD2_BEL','HM','EE','HM_true','EE_true','SEQ_1','SEQ_2','SEQ_5'};
statistic_list = {'average','bias','var','std','time','iter'};
gamma_a_list = [0,1,2,5];
norm_p=[];
norm_p_modified=[];

[F_struct,state] = DDCMixture.statetransition(param); %Generate
F_0 = kron([0,1;0,1],F_struct{2});
F_1 = kron([1,0;1,0],F_struct{1});
F   = [F_0;F_1];

F_til = F_1 - F_0;
param.P     = F_struct;
param.state = state;
param.n_type = 1;
param.n_action = 2;

theta_vec = [theta.VP0,theta.VP1,theta.VP2,theta.FC0,theta.FC1,theta.EC0,theta.EC1]';

ev=zeros(param.n_state,param.n_action);
pi = DDCMixture.dpidth(param) * theta_vec;
[p1,ev] = DDCMixture.solveNFXP(ev,pi,param); 


u_til = pi + log(1-p1) - log(p1);
u_0 = 0.5772156649015328606065120900824 - log(1-p1);

disp(max(abs(u_til + param.beta * F_til * V)));
kk = null(F_til);
V_eps = V + kk(:,3);
disp(max(abs(u_til + param.beta * F_til * V_eps)));

max(V - u_0 - param.beta *F_0 * V)
lambda = pinv(F_til) * (u_til );
lambda2 = - param.beta * ev(:);
F_til * (lambda + param.beta * ( u_0 - F_0 * lambda) )
F_til * (lambda2 + param.beta * ( u_0 - F_0 * lambda2) )
